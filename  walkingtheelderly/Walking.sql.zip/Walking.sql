-- phpMyAdmin SQL Dump
-- version 3.1.3
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Mai 16, 2009 as 05:20 PM
-- Versão do Servidor: 5.1.32
-- Versão do PHP: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `Walking`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `combina`
--

CREATE TABLE IF NOT EXISTS `combina` (
  `Id_viagem_1` int(11) NOT NULL,
  `Id_viagem_2` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `combina`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `Feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `Nota` tinyint(4) NOT NULL,
  `Justificativa` text COLLATE utf8_unicode_ci,
  `Responsavel_nIdoso` tinyint(1) NOT NULL,
  `CPF` int(11) NOT NULL,
  `CPF_Idoso` int(11) NOT NULL,
  PRIMARY KEY (`Feedback_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `feedback`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `idoso`
--

CREATE TABLE IF NOT EXISTS `idoso` (
  `CPF_IDOSO` int(11) NOT NULL,
  `Nome` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Endereco` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Numero_endereco` int(11) NOT NULL,
  `RG` int(11) NOT NULL,
  `Cidade` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Estado` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Bairro` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Telefone` int(11) DEFAULT NULL,
  `Email` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `Fumo` tinyint(1) DEFAULT NULL,
  `Alcool` tinyint(1) DEFAULT NULL,
  `Medicamentos` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  PRIMARY KEY (`CPF_IDOSO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `idoso`
--

INSERT INTO `idoso` (`CPF_IDOSO`, `Nome`, `Endereco`, `Numero_endereco`, `RG`, `Cidade`, `Estado`, `Bairro`, `Telefone`, `Email`, `Fumo`, `Alcool`, `Medicamentos`) VALUES
(9188, 'Balzac', 'rua piraporinha', 45656, 0, 'são paulo', 'são paulo', 'moema', 465456, 'fuiyhfui', NULL, NULL, 'Remédios:\r\ndiazepan, prozac\r\nsofre de:\r\nepilepcia, coração e disturbios mentais.');

-- --------------------------------------------------------

--
-- Estrutura da tabela `responsavel`
--

CREATE TABLE IF NOT EXISTS `responsavel` (
  `CPF` int(11) NOT NULL,
  `RG` int(11) NOT NULL,
  `Nome` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Endereco` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Cidade` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Estado` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Bairro` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Telefone` int(11) DEFAULT NULL,
  `email` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `fumo` tinyint(1) DEFAULT NULL,
  `alcool` tinyint(1) DEFAULT NULL,
  `observacoes` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `CPF_Idoso` int(11) DEFAULT NULL,
  `Numero_endereco` int(11) NOT NULL,
  PRIMARY KEY (`CPF`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `responsavel`
--

INSERT INTO `responsavel` (`CPF`, `RG`, `Nome`, `Endereco`, `Cidade`, `Estado`, `Bairro`, `Telefone`, `email`, `fumo`, `alcool`, `observacoes`, `CPF_Idoso`, `Numero_endereco`) VALUES
(1, 1, 'Ronaldo Tadashi da Silva Miura', 'rua eng. jose salles', 'são paulo', 'SP', 'socorro', 1, '1', 0, 0, 'admin', 0, 0),
(116516, 43546646, 'Manoel', 'rua. ouro preto', 'são paulo', 'SP', 'moema', 10, 'vai@gmail.com', 1, 0, 'ffffffffffffffff', 9188, 123);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `Username` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Nome de usuario',
  `CPF` int(11) DEFAULT NULL,
  `Senha` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tabela de usuarios';

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`Username`, `CPF`, `Senha`, `Admin`) VALUES
('ronaldotadashi', 1, 'admin', 1),
('2', 116516, '123', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `viagem`
--

CREATE TABLE IF NOT EXISTS `viagem` (
  `Id_viagem` int(11) NOT NULL AUTO_INCREMENT,
  `Data_inicio` int(11) NOT NULL,
  `Data_fim` int(11) NOT NULL,
  `CPF` int(11) NOT NULL,
  `Cidade` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Estado` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id_viagem`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `viagem`
--

INSERT INTO `viagem` (`Id_viagem`, `Data_inicio`, `Data_fim`, `CPF`, `Cidade`, `Estado`) VALUES
(1, 10122009, 11102010, 116516, 'caçapava', 'SP');
